package com.example.demo.Service;

import static org.junit.jupiter.api.Assertions.*;

class SiloServiceTest {

}