package com.example.demo;

public class NoMoreTryException extends Throwable {
}
